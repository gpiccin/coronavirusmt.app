'use strict';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "index.html": "1bc35e740048cd22ca683777f90b2bec",
"/": "1bc35e740048cd22ca683777f90b2bec",
"main.dart.js": "d673c54e7ec4493ce6602c9c82387f3c",
"favicon.png": "49bf7c946767cf4e96f7f30402b226d1",
"icons/Icon-192.png": "ec0a55f20d3de66177d3a80c0d82825c",
"icons/Icon-512.png": "0bd73031a7c3734d8153ec73b4212cfc",
"manifest.json": "4c4f4d123ad2c90a8d6aa5357857e218",
"assets/LICENSE": "0323ac70f659e513c3aa261e4ea52ae3",
"assets/AssetManifest.json": "61e6323087e19d61843199c70a14a550",
"assets/FontManifest.json": "01700ba55b08a6141f33e168c4a6c22f",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "115e937bb829a890521f72d2e664b632",
"assets/fonts/MaterialIcons-Regular.ttf": "56d3ffdef7a25659eab6a68a3fbfaf16",
"assets/assets/images/virus.png": "29cbf93ec672ce857fe6d9ccdeba7adf",
"assets/assets/lotties/stay-safe-stay-home.json": "00d832454a534c3fb2b4bfbeb7fecf02"
};

self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (cacheName) {
      return caches.delete(cacheName);
    }).then(function (_) {
      return caches.open(CACHE_NAME);
    }).then(function (cache) {
      return cache.addAll(Object.keys(RESOURCES));
    })
  );
});

self.addEventListener('fetch', function (event) {
  event.respondWith(
    caches.match(event.request)
      .then(function (response) {
        if (response) {
          return response;
        }
        return fetch(event.request);
      })
  );
});
