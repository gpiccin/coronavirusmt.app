'use strict';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "index.html": "9ba27d186be5f345436de583740571e5",
"/": "9ba27d186be5f345436de583740571e5",
"main.dart.js": "58f4f41cb8f60e3670981563197c5b4b",
"favicon.png": "49bf7c946767cf4e96f7f30402b226d1",
"static/img/wapp.png": "89e585b790e1e664096347b19e637aab",
"static/icons/Icon-192.png": "ec0a55f20d3de66177d3a80c0d82825c",
"static/icons/Icon-512.png": "0bd73031a7c3734d8153ec73b4212cfc",
"manifest.json": "384cc2da9217594b69a60f94a5c3a720",
"assets/LICENSE": "0323ac70f659e513c3aa261e4ea52ae3",
"assets/AssetManifest.json": "61e6323087e19d61843199c70a14a550",
"assets/FontManifest.json": "01700ba55b08a6141f33e168c4a6c22f",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "115e937bb829a890521f72d2e664b632",
"assets/fonts/MaterialIcons-Regular.ttf": "56d3ffdef7a25659eab6a68a3fbfaf16",
"assets/assets/images/virus.png": "29cbf93ec672ce857fe6d9ccdeba7adf",
"assets/assets/lotties/stay-safe-stay-home.json": "00d832454a534c3fb2b4bfbeb7fecf02"
};

self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (cacheName) {
      return caches.delete(cacheName);
    }).then(function (_) {
      return caches.open(CACHE_NAME);
    }).then(function (cache) {
      return cache.addAll(Object.keys(RESOURCES));
    })
  );
});

self.addEventListener('fetch', function (event) {
  event.respondWith(
    caches.match(event.request)
      .then(function (response) {
        if (response) {
          return response;
        }
        return fetch(event.request);
      })
  );
});
